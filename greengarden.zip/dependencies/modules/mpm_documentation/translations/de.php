<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_documentation}prestashop>mpm_documentation_4981a4927bfd6e7f1137342b99fe0453'] = 'Template documentation';
$_MODULE['<{mpm_documentation}prestashop>mpm_documentation_94c035882dab9e7507f9e9e15a2dc8c3'] = 'Template documentation.';
