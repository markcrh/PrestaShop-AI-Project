<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_brands}prestashop>mpm_brands_84be54bb4bd1b755a27d86388700d097'] = 'Brands';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_9de8655af6d2bdde9047c624ff92ba1e'] = 'Brands block.';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_876f23178c29dc2552c0b48bf23cd9bd'] = 'Are you sure you want to uninstall?';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_85ab0c0d250e58397e95c96277a3f8e3'] = 'Invalid number of elements.';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_f38f5974cdc23279ffe6d203641a8bdf'] = 'Settings updated.';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_19fb21d55a90e1c8d1d88cdcc8becbda'] = 'displayHomeContent1';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_940598f5e00b8924dae0d72aa03542bb'] = 'displayHomeContent2';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_d0c6b51eb278a01ec6df0dfb6a5b6320'] = 'displayHomeContent3';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_5ed5cbf5b35713c3951dfc84c09be952'] = 'displayHomeContent4';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_cecece906a89a2ea0af8ef6de320aa2b'] = 'displayHomeContent5';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_e5b64a50c0e0da0bb75295fad5f9f8d5'] = 'Center column settings';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_d26d18db532a87e11f050025becada47'] = 'Display brands in center column';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_b9b371458ab7c314f88b81c553f6ce51'] = 'Hook';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_95a272750caac0cbab024c7425fcdbce'] = 'Display brands title';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_26c65d0578cc50c37e87da3af72c82d0'] = 'Display brand title below logo.';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_1596466e53b9be856f2fa94c7d89ec33'] = 'Left column settings';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_11633465b2e6bd2fa6177a1063a8efaa'] = 'Display brands in the left column';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_4f7ca31098b9aed354be423f9c997ee7'] = 'Number of brands to display';
$_MODULE['<{mpm_brands}prestashop>mpm_brands_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{mpm_brands}prestashop>blockmanufacturer_84be54bb4bd1b755a27d86388700d097'] = 'Brands';
$_MODULE['<{mpm_brands}prestashop>blockmanufacturer_c70ad5f80e4c6f299013e08cabc980df'] = 'More about %s';
$_MODULE['<{mpm_brands}prestashop>brands_84be54bb4bd1b755a27d86388700d097'] = 'Brands';
