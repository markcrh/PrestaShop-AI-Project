INSTALLATION INSTRUCTION 

For installation this module you need to copy folder “blog” to your modules folder. For example "www/modules/". After copying the module go to the admin panel of your shop, select tab modules->modules, click on "Front Office Features" category. Where you will find module "Functional Blog", press install.