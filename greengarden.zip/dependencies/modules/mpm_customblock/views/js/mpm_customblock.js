$(document).ready(function(){
  if( $('.customblock .custom-list-item').length > 0 ){
    setTimeout(function () {
      sizeCustomList();
    },50);
  }
});


function sizeCustomList(){

  var height_item = 10;

  $('.customblock .custom-list-item').each(function() {
    var height_current = $(this).outerHeight();
    if(height_current > height_item){
      height_item = height_current;
    }
  });

  $('.customblock .custom-list-item').css('height', height_item+'px');
  $('.customblock .custom-list').css('height', height_item+'px');


}