<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_customblock}prestashop>mpm_customblock_43ebe67a66ec2b47f3f17367521f5b50'] = 'Custom block on homepage';
$_MODULE['<{mpm_customblock}prestashop>mpm_customblock_8e0af8b5e016b2d31189609f16d276db'] = 'Custom block on homepage.';
$_MODULE['<{mpm_customblock}prestashop>mpm_customblock_876f23178c29dc2552c0b48bf23cd9bd'] = 'Sei sicuro di voler disinstallare?';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_d3b206d196cd6be3a2764c1fb90b200f'] = 'Elimina selezione';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_e25f0ecd41211b01c83e5fec41df4fe7'] = 'Eliminare gli elementi selezionati?';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_b78a3223503896721cca1303f776159b'] = 'Titolo';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_86754577897acfb25deb69039d49d9a7'] = 'Mostrata';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Posizione';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_7b6e7f81d1c260b7068ca82b91eb90a7'] = 'Data Aggiungi';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_19fb21d55a90e1c8d1d88cdcc8becbda'] = 'displayHomeContent1';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_940598f5e00b8924dae0d72aa03542bb'] = 'displayHomeContent2';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_d0c6b51eb278a01ec6df0dfb6a5b6320'] = 'displayHomeContent3';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_5ed5cbf5b35713c3951dfc84c09be952'] = 'displayHomeContent4';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_cecece906a89a2ea0af8ef6de320aa2b'] = 'displayHomeContent5';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_b9b371458ab7c314f88b81c553f6ce51'] = 'Hook';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Attivo';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_93cba07454f06a4a960172bbd6e2a435'] = 'Sì';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_792744786ed30c5623dd1cf0c16f4ffe'] = 'Selezionare un file';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Descrizione';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_6252c0f2c2ed83b7b06dfca86d4650bb'] = 'Caratteri non validi:';
$_MODULE['<{mpm_customblock}prestashop>admincustomblockcontroller_9ea67be453eaccf020697b4654fc021a'] = 'Salva e rimani';
