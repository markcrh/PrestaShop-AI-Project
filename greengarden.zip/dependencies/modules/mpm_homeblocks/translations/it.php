<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_homeblocks}prestashop>mpm_homeblocks_9bf32a5f226323faea682d3a6b91123a'] = 'Home page custom blocks';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_d3b206d196cd6be3a2764c1fb90b200f'] = 'Elimina selezione';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_e25f0ecd41211b01c83e5fec41df4fe7'] = 'Eliminare gli elementi selezionati?';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_b78a3223503896721cca1303f776159b'] = 'Titolo';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_86754577897acfb25deb69039d49d9a7'] = 'Mostrata';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Posizione';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_7b6e7f81d1c260b7068ca82b91eb90a7'] = 'Data Aggiungi';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_a4ffdcf0dc1f31b9acaf295d75b51d00'] = 'In alto';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_4f1f6016fc9f3f2353c0cc7c67b292bd'] = 'Al centro';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_2ad9d63b69c4a10a5cc9cad923133bc4'] = 'Fondo';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Attivo';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_93cba07454f06a4a960172bbd6e2a435'] = 'Sì';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_66c5eabfa8e606780ffc8e5482651009'] = 'Non è esposto nel front office';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_32954654ac8fe66a1d09be19001de2d4'] = 'Larghezza';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_cb5298bdde6546e4aa6bcd4a0ba04214'] = 'Larghezza del blocco in';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Lenke';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_53b8b5fdde0428a14002414199f51ca7'] = 'Posizione della Descrizione';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_a9ded1e5ce5d75814730bb4caaf49419'] = 'Sfondo';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_6f7d1ec7ec17033b4973444ccfe99b9f'] = 'Descrizione del blocco di sinistra';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_6252c0f2c2ed83b7b06dfca86d4650bb'] = 'Caratteri non validi';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_9ea67be453eaccf020697b4654fc021a'] = 'Salva e rimani';
